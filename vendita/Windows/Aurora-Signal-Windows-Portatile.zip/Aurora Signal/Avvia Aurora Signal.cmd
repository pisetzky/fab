@echo off
start "" "%~dp0aurora-signal.html"
