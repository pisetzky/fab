#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
for B in google-chrome chromium chromium-browser microsoft-edge brave-browser; do
  command -v "$B" >/dev/null 2>&1 && exec "$B" --app="file://$DIR/aurora-signal.html"
done
exec xdg-open "$DIR/aurora-signal.html"
