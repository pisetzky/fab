#!/bin/sh
# Aggiunge Aurora Signal al menu delle applicazioni
set -e
DIR="$HOME/.local/share/aurora-signal"
mkdir -p "$DIR" "$HOME/.local/share/applications"
cp "$(dirname "$0")"/aurora-signal.html "$(dirname "$0")"/aurora-signal.sh "$(dirname "$0")"/icon.png "$DIR/"
chmod +x "$DIR/aurora-signal.sh"
cat > "$HOME/.local/share/applications/aurora-signal.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Aurora Signal
Comment=Segnali compra/vendi per le criptovalute
Exec="$DIR/aurora-signal.sh"
Icon=$DIR/icon.png
Categories=Finance;Office;
Terminal=false
EOF
echo "Aurora Signal installato: lo trovi nel menu delle applicazioni."
